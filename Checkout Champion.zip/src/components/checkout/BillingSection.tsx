import { useState } from "react";
import { Lock, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import type { BillingProfile, ProfileKind } from "@/lib/checkout";

type Props = {
  profiles: Record<ProfileKind, BillingProfile>;
  active: ProfileKind;
  onChangeActive: (k: ProfileKind) => void;
  onRegister: (k: ProfileKind, data: Partial<BillingProfile>) => void;
};

export function BillingSection({ profiles, active, onChangeActive, onRegister }: Props) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", doc: "", phone: "", address: "" });
  const current = profiles[active];
  const locked = active === "pj" && profiles.pj.locked === true;

  return (
    <section aria-label="Dados de faturamento" className="rounded-2xl border border-border bg-background p-5">
      <h2 className="text-base font-bold">Dados de faturamento</h2>

      <div
        role="tablist"
        aria-label="Tipo de perfil"
        className="mt-3 grid grid-cols-2 gap-1 rounded-xl bg-muted p-1"
      >
        {(["pf", "pj"] as ProfileKind[]).map((k) => (
          <button
            key={k}
            role="tab"
            aria-selected={active === k}
            onClick={() => onChangeActive(k)}
            className={`min-h-11 rounded-lg text-sm font-semibold transition-colors ${
              active === k ? "bg-background shadow-sm" : "text-muted-foreground"
            }`}
          >
            {k === "pf" ? "Pessoa física" : "Pessoa jurídica"}
          </button>
        ))}
      </div>

      <div className="mt-3 rounded-xl border border-border p-3">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{current.name}</p>
            <p className="truncate text-sm text-muted-foreground">{current.doc}</p>
            <p className="mt-0.5 truncate text-xs text-muted-foreground">{current.address}</p>
          </div>
          {locked ? (
            <TooltipProvider delayDuration={150}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span
                    tabIndex={0}
                    className="flex shrink-0 cursor-help items-center gap-1 rounded-full border border-border px-2.5 py-1 text-xs font-semibold text-muted-foreground"
                  >
                    <Lock className="size-3.5" aria-hidden /> fixo
                  </span>
                </TooltipTrigger>
                <TooltipContent className="max-w-56 text-xs">
                  Perfil de pessoa jurídica já cadastrado. Para alterar razão social, CNPJ ou
                  endereço, fale com o time.
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ) : (
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="shrink-0 text-brand"
                  aria-label="Editar dados de faturamento"
                >
                  <Pencil className="size-3.5" aria-hidden /> Editar
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Dados de {active === "pf" ? "pessoa física" : "pessoa jurídica"}</DialogTitle>
                </DialogHeader>
                <div className="grid gap-3">
                  <Field
                    id="reg-name"
                    label={active === "pf" ? "Nome completo" : "Razão social"}
                    value={form.name}
                    onChange={(v) => setForm({ ...form, name: v })}
                  />
                  <Field
                    id="reg-doc"
                    label={active === "pf" ? "CPF" : "CNPJ"}
                    value={form.doc}
                    onChange={(v) => setForm({ ...form, doc: v })}
                  />
                  <Field
                    id="reg-phone"
                    label="Telefone"
                    value={form.phone}
                    onChange={(v) => setForm({ ...form, phone: v })}
                  />
                  <Field
                    id="reg-address"
                    label="Endereço"
                    value={form.address}
                    onChange={(v) => setForm({ ...form, address: v })}
                  />
                  <Button
                    className="min-h-12"
                    onClick={() => {
                      onRegister(active, {
                        name: form.name || current.name,
                        doc: form.doc || current.doc,
                        address: form.address || current.address,
                        registered: true,
                      });
                      setOpen(false);
                    }}
                  >
                    Salvar
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
        {locked && (
          <p className="mt-2 border-t border-border pt-2 text-xs text-muted-foreground">
            Perfil PJ já cadastrado.{" "}
            <a href="#ajuda" className="font-semibold text-brand underline">
              Falar com o time
            </a>
          </p>
        )}
      </div>
    </section>
  );
}

function Field({
  id,
  label,
  value,
  onChange,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <Label htmlFor={id} className="text-xs font-semibold">
        {label}
      </Label>
      <Input id={id} className="mt-1 h-11" value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
