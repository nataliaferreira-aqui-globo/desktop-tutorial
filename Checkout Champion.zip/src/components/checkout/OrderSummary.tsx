import { useState } from "react";
import { Plus, Check, Tag, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { addOns, brl, order } from "@/lib/checkout";

type Props = {
  subtotal: number;
  discount: number;
  total: number;
  coupon: string | null;
  couponError: string | null;
  onApplyCoupon: (code: string) => void;
  onRemoveCoupon: () => void;
  selectedAddOns: string[];
  onToggleAddOn: (id: string) => void;
};

export function OrderSummary({
  subtotal,
  discount,
  total,
  coupon,
  couponError,
  onApplyCoupon,
  onRemoveCoupon,
  selectedAddOns,
  onToggleAddOn,
}: Props) {
  const [openCoupon, setOpenCoupon] = useState(false);
  const [code, setCode] = useState("");

  return (
    <>
      <div className="rounded-2xl border border-border bg-background p-5">
        <h2 className="text-base font-bold">Resumo do pedido</h2>

        <dl className="mt-3 grid gap-2 text-sm">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3">
            <dt className="min-w-0 truncate text-muted-foreground">{order.campaign}</dt>
            <dd>{brl(subtotal)}</dd>
          </div>
          {discount > 0 && (
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3 text-success">
              <dt className="min-w-0 truncate">Desconto</dt>
              <dd>−{brl(discount)}</dd>
            </div>
          )}
        </dl>

        <div className="mt-3 border-t border-border pt-3">
          {coupon ? (
            <div className="flex items-center gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 font-semibold">
                <Tag className="size-3.5" aria-hidden /> {coupon}
                <button onClick={onRemoveCoupon} aria-label={`Remover cupom ${coupon}`}>
                  <X className="size-3.5" aria-hidden />
                </button>
              </span>
              <span className="text-success">cupom aplicado</span>
            </div>
          ) : (
            <>
              <button
                className="text-xs font-semibold text-brand underline"
                onClick={() => setOpenCoupon((v) => !v)}
              >
                Tenho um cupom
              </button>
              {openCoupon && (
                <div className="mt-2">
                  <div className="flex gap-2">
                    <Input
                      aria-label="Código do cupom"
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      className="h-11"
                    />
                    <Button variant="secondary" className="h-11" onClick={() => onApplyCoupon(code)}>
                      Aplicar
                    </Button>
                  </div>
                  {couponError && (
                    <p role="alert" className="mt-1 text-xs text-destructive">
                      {couponError}
                    </p>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        <div className="mt-3 grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3 border-t border-border pt-4">
          <p className="font-semibold leading-tight">Total</p>
          <p className="shrink-0 text-2xl font-extrabold leading-none">{brl(total)}</p>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          {order.weeks} semanas · {order.startNote}
        </p>

        <div className="mt-4 border-t border-border pt-3">
          <p className="text-xs font-semibold text-muted-foreground">
            Quer incluir no mesmo pedido?
          </p>
          <ul className="mt-2 grid gap-2">
            {addOns.map((a) => {
              const on = selectedAddOns.includes(a.id);
              return (
                <li key={a.id}>
                  <button
                    onClick={() => onToggleAddOn(a.id)}
                    aria-pressed={on}
                    className={`grid w-full grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-xl border px-3 py-2.5 text-left ${
                      on ? "border-brand bg-accent" : "border-border"
                    }`}
                  >
                    <span className="min-w-0 truncate text-sm">{a.title}</span>
                    <span className="flex shrink-0 items-center gap-1 text-xs font-semibold">
                      {brl(a.price)}
                      {on ? (
                        <Check className="size-3.5 text-brand" aria-hidden />
                      ) : (
                        <Plus className="size-3.5" aria-hidden />
                      )}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </>
  );
}
