import { useEffect, useState } from "react";
import { Barcode, Check, Clock, CreditCard, Zap } from "lucide-react";
import QRCode from "qrcode";

import { VisaBadge, MastercardBadge, HipercardBadge } from "./CardBrandBadges";

import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  BOLETO_LINE,
  BOLETO_MIN,
  brl,
  maxInstallments,
  methodMeta,
  savedCard,
  type Method,
  type PlanWeeks,
} from "@/lib/checkout";

export type CardErrors = Partial<Record<keyof CardForm, string>>;

export type CardForm = {
  number: string;
  exp: string;
  cvv: string;
  name: string;
  doc: string;
};

type Props = {
  total: number;
  weeks: PlanWeeks;
  method: Method;
  onMethod: (m: Method) => void;
  installments: number;
  onInstallments: (n: number) => void;
  card: CardForm;
  onCard: (c: CardForm) => void;
  errors: CardErrors;
  pix: { code: string; expiresAt: number } | null;
  boletoIssued: boolean;
  useSavedCard: boolean;
  onUseSavedCard: (v: boolean) => void;
  saveCard: boolean;
  onSaveCard: (v: boolean) => void;
};

const icons: Record<Method, typeof Zap> = {
  pix: Zap,
  card: CreditCard,
  boleto: Barcode,
};

export function PaymentSection({
  total,
  weeks,
  method,
  onMethod,
  installments,
  onInstallments,
  card,
  onCard,
  errors,
  pix,
  boletoIssued,
  useSavedCard,
  onUseSavedCard,
  saveCard,
  onSaveCard,
}: Props) {
  const max = maxInstallments(total, weeks);

  return (
    <section aria-label="Forma de pagamento" className="grid gap-2">
      <div className="mb-1">
        <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Como você quer pagar?
        </h2>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Escolha uma opção. Dá para mudar antes de confirmar.
        </p>
      </div>
      {(["pix", "card", "boleto"] as Method[]).map((m) => {
        const Icon = icons[m];
        const disabled = m === "boleto" && total < BOLETO_MIN;
        const selected = method === m;
        return (
          <div key={m}>
            <button
              role="radio"
              aria-checked={selected}
              disabled={disabled}
              onClick={() => onMethod(m)}
              className={`grid w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-2xl border px-4 py-3.5 text-left transition-colors ${
                selected ? "border-brand bg-accent" : "border-border bg-background"
              } ${disabled ? "cursor-not-allowed opacity-50" : ""}`}
            >
              <Icon
                className={`size-5 shrink-0 ${selected ? "text-brand" : "text-muted-foreground"}`}
                aria-hidden
              />
              <span className="min-w-0">
                <span className="block truncate font-semibold">{methodMeta[m].label}</span>
                <span className="block truncate text-xs text-muted-foreground">
                  {m === "card" && max > 1 ? `até ${max}x sem juros` : methodMeta[m].speed}
                </span>
              </span>
              {selected && <Check className="size-5 shrink-0 text-brand" aria-hidden />}
            </button>

            {selected && (
              <div className="mt-2 rounded-2xl border border-border bg-background p-4">
                {m === "pix" && <PixPanel pix={pix} />}
                {m === "card" && (
                  <CardPanel
                    total={total}
                    max={max}
                    installments={installments}
                    onInstallments={onInstallments}
                    card={card}
                    onCard={onCard}
                    errors={errors}
                    useSavedCard={useSavedCard}
                    onUseSavedCard={onUseSavedCard}
                    saveCard={saveCard}
                    onSaveCard={onSaveCard}
                  />
                )}
                {m === "boleto" && <BoletoPanel issued={boletoIssued} />}
              </div>
            )}
          </div>
        );
      })}
    </section>
  );
}

function BrandRow() {
  return (
    <span className="flex items-center gap-1.5" aria-label="Bandeiras aceitas: Visa, Mastercard e Hipercard">
      <VisaBadge />
      <MastercardBadge />
      <HipercardBadge />
    </span>
  );
}

function PixPanel({ pix }: { pix: { code: string; expiresAt: number } | null }) {
  const [left, setLeft] = useState(15 * 60);
  const [qr, setQr] = useState<string | null>(null);

  useEffect(() => {
    if (!pix) return;
    const t = setInterval(
      () => setLeft(Math.max(0, Math.round((pix.expiresAt - Date.now()) / 1000))),
      1000,
    );
    return () => clearInterval(t);
  }, [pix]);

  useEffect(() => {
    if (!pix) return;
    let alive = true;
    QRCode.toDataURL(pix.code, { margin: 0, width: 220 })
      .then((url) => alive && setQr(url))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [pix]);

  if (!pix) {
    return (
      <p className="text-sm text-muted-foreground">
        Você recebe um código para colar no app do banco. Prazo: 15 minutos.
      </p>
    );
  }

  const mm = String(Math.floor(left / 60)).padStart(2, "0");
  const ss = String(left % 60).padStart(2, "0");

  return (
    <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
      <div className="min-w-0">
        <p className="rounded-xl bg-muted px-3 py-3 font-mono text-xs break-all text-muted-foreground">
          {pix.code}
        </p>
        <p
          className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground"
          aria-live="polite"
        >
          <Clock className="size-3.5" aria-hidden /> expira em {mm}:{ss}
        </p>
      </div>
      {qr && (
        <div className="hidden sm:block">
          <img
            src={qr}
            alt="QR Code do Pix"
            className="size-24 rounded-lg border border-border bg-background p-1"
          />
          <p className="mt-1 text-center text-[10px] text-muted-foreground">ou escaneie</p>
        </div>
      )}
    </div>
  );
}

function CardPanel({
  total,
  max,
  installments,
  onInstallments,
  card,
  onCard,
  errors,
  useSavedCard,
  onUseSavedCard,
  saveCard,
  onSaveCard,
}: {
  total: number;
  max: number;
  installments: number;
  onInstallments: (n: number) => void;
  card: CardForm;
  onCard: (c: CardForm) => void;
  errors: CardErrors;
  useSavedCard: boolean;
  onUseSavedCard: (v: boolean) => void;
  saveCard: boolean;
  onSaveCard: (v: boolean) => void;
}) {
  const set = (k: keyof CardForm) => (v: string) => onCard({ ...card, [k]: v });

  return (
    <div className="grid gap-3">
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground">Aceitamos</span>
        <BrandRow />
      </div>
      <div role="radiogroup" aria-label="Cartão" className="grid gap-2">
        <button
          role="radio"
          aria-checked={useSavedCard}
          onClick={() => onUseSavedCard(true)}
          className={`grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl border px-3 py-3 text-left ${
            useSavedCard ? "border-brand bg-accent" : "border-border"
          }`}
        >
          <CreditCard className="size-4 shrink-0 text-muted-foreground" aria-hidden />
          <span className="min-w-0">
            <span className="block truncate text-sm font-semibold">
              {savedCard.brand} •••• {savedCard.last4}
            </span>
            <span className="block text-xs text-muted-foreground">
              Cartão salvo · validade {savedCard.exp}
            </span>
          </span>
          {useSavedCard && <Check className="size-4 text-brand" aria-hidden />}
        </button>
        <button
          role="radio"
          aria-checked={!useSavedCard}
          onClick={() => onUseSavedCard(false)}
          className={`rounded-xl border px-3 py-3 text-left text-sm font-semibold ${
            !useSavedCard ? "border-brand bg-accent" : "border-border"
          }`}
        >
          Usar outro cartão
        </button>
      </div>

      {useSavedCard ? (
        <CardField
          id="cc-cvv"
          label="CVV do cartão salvo"
          autoComplete="cc-csc"
          inputMode="numeric"
          placeholder="000"
          value={card.cvv}
          error={errors.cvv ?? undefined}
          onChange={(v) => set("cvv")(v.replace(/\D/g, "").slice(0, 4))}
        />
      ) : (
        <>
          <CardField
            id="cc-number"
            label="Número do cartão"
            autoComplete="cc-number"
            inputMode="numeric"
            placeholder="0000 0000 0000 0000"
            value={card.number}
            error={errors.number ?? undefined}
            onChange={(v) =>
              set("number")(v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim())
            }
          />
          <div className="grid grid-cols-2 gap-3">
            <CardField
              id="cc-exp"
              label="Validade"
              autoComplete="cc-exp"
              inputMode="numeric"
              placeholder="MM/AA"
              value={card.exp}
              error={errors.exp ?? undefined}
              onChange={(v) => {
                const d = v.replace(/\D/g, "").slice(0, 4);
                set("exp")(d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d);
              }}
            />
            <CardField
              id="cc-cvv"
              label="CVV"
              autoComplete="cc-csc"
              inputMode="numeric"
              placeholder="000"
              value={card.cvv}
              error={errors.cvv ?? undefined}
              onChange={(v) => set("cvv")(v.replace(/\D/g, "").slice(0, 4))}
            />
          </div>
          <CardField
            id="cc-name"
            label="Nome no cartão"
            autoComplete="cc-name"
            value={card.name}
            error={errors.name ?? undefined}
            onChange={set("name")}
          />
          <CardField
            id="cc-doc"
            label="CPF/CNPJ do titular"
            inputMode="numeric"
            value={card.doc}
            error={errors.doc ?? undefined}
            onChange={set("doc")}
          />
          <label className="flex items-center gap-2 text-sm">
            <Checkbox
              checked={saveCard}
              onCheckedChange={(v) => onSaveCard(v === true)}
              aria-label="Salvar cartão"
            />
            Salvar cartão para as próximas campanhas
          </label>
        </>
      )}

      {max > 1 && (
        <div>
          <Label htmlFor="parcelas" className="text-xs font-semibold">
            Parcelas
          </Label>
          <select
            id="parcelas"
            value={installments}
            onChange={(e) => onInstallments(Number(e.target.value))}
            className="mt-1 h-12 w-full rounded-xl border border-border bg-background px-3 text-sm"
          >
            {Array.from({ length: max }, (_, i) => i + 1).map((n) => (
              <option key={n} value={n}>
                {n}x {brl(total / n)} {n === 1 ? "à vista" : "sem juros"}
              </option>
            ))}
          </select>
        </div>
      )}
    </div>
  );
}

function CardField({
  id,
  label,
  value,
  onChange,
  error,
  ...rest
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  error?: string | undefined;
  placeholder?: string;
  inputMode?: "numeric";
  autoComplete?: string;
}) {
  return (
    <div>
      <Label htmlFor={id} className="text-xs font-semibold">
        {label}
      </Label>
      <Input
        id={id}
        {...rest}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${id}-err` : undefined}
        className={`mt-1 h-12 ${error ? "border-destructive" : ""}`}
      />
      {error && (
        <p id={`${id}-err`} role="alert" className="mt-1 text-xs text-destructive">
          {error}
        </p>
      )}
    </div>
  );
}

function BoletoPanel({ issued }: { issued: boolean }) {
  if (!issued) {
    return (
      <p className="text-sm text-muted-foreground">
        Vence em 1 dia útil. A campanha começa após a confirmação.
      </p>
    );
  }
  return (
    <div>
      <p className="rounded-xl bg-muted px-3 py-3 font-mono text-xs break-all text-muted-foreground">
        {BOLETO_LINE}
      </p>
      <p className="mt-2 text-xs text-muted-foreground">
        Vence em 1 dia útil · compensa em até 2 dias úteis
      </p>
    </div>
  );
}
