import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CheckoutHeader } from "@/components/checkout/CheckoutHeader";
import { BillingSection } from "@/components/checkout/BillingSection";
import {
  PaymentSection,
  type CardForm,
  type CardErrors,
} from "@/components/checkout/PaymentSection";
import { OrderSummary } from "@/components/checkout/OrderSummary";
import { HelpAccordion } from "@/components/checkout/HelpAccordion";
import {
  addOns,
  BOLETO_LINE,
  brl,
  coupons,
  luhn,
  maxInstallments,
  order,
  validateExpiry,
  type BillingProfile,
  type Method,
  type ProfileKind,
} from "@/lib/checkout";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Pagamento da campanha | Aqui Ads" },
      {
        name: "description",
        content:
          "Finalize o pagamento da sua campanha Aqui Ads com Pix, cartão ou boleto em poucos toques.",
      },
      { property: "og:title", content: "Pagamento da campanha | Aqui Ads" },
      {
        property: "og:description",
        content: "Checkout rápido da Aqui Ads: Pix copia e cola, cartão sem juros e boleto.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex,follow" },
    ],
  }),
  component: CheckoutPage,
});

const initialProfiles: Record<ProfileKind, BillingProfile> = {
  pf: {
    kind: "pf",
    name: "Natália Ferreira Rosário Silva",
    doc: "CPF 459.444.008-89",
    address: "Estrada do Limoeiro, 595, Jacareí, SP",
    registered: true,
  },
  pj: {
    kind: "pj",
    name: "GLOBO COMUNICACAO E PARTICIPACOES S/A",
    doc: "CNPJ 27.865.757/0069-92",
    address: "Av. das Américas, 1650, Rio de Janeiro, RJ",
    registered: true,
    locked: true,
  },
};

function CheckoutPage() {
  const [profiles, setProfiles] = useState(initialProfiles);
  const [activeProfile, setActiveProfile] = useState<ProfileKind>("pj");
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [coupon, setCoupon] = useState<string | null>("BZZLD30");
  const [couponError, setCouponError] = useState<string | null>(null);
  const [method, setMethod] = useState<Method>("pix");
  const [installmentsRaw, setInstallments] = useState(1);
  const [card, setCard] = useState<CardForm>({
    number: "",
    exp: "",
    cvv: "",
    name: "",
    doc: "",
  });
  const [errors, setErrors] = useState<CardErrors>({});
  const [pix, setPix] = useState<{ code: string; expiresAt: number } | null>(null);
  const [boletoIssued, setBoletoIssued] = useState(false);
  const [failure, setFailure] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const [useSavedCard, setUseSavedCard] = useState(true);
  const [saveCard, setSaveCard] = useState(false);
  const [copied, setCopied] = useState(false);

  const subtotal =
    order.subtotal +
    addOns.filter((a) => selectedAddOns.includes(a.id)).reduce((s, a) => s + a.price, 0);
  const applied = coupon ? coupons[coupon] : null;
  const discount = applied ? subtotal * applied.off : 0;
  const total = subtotal - discount;
  const max = useMemo(() => maxInstallments(total, order.weeks), [total]);
  const installments = Math.min(installmentsRaw, max);

  useEffect(() => {
    if (method === "pix" && !pix) {
      setPix({
        code: "00020126580014BR.GOV.BCB.PIX0136aqui-ads-9f2c4b7e-52a1-4c3d-8b0a5204000053039865802BR5910AQUI ADS6009SAO PAULO62070503***6304A1B2",
        expiresAt: Date.now() + 15 * 60 * 1000,
      });
    }
    if (method === "boleto") setBoletoIssued(true);
  }, [method, pix]);

  const ctaLabel =
    method === "card"
      ? installments > 1
        ? `Pagar ${installments}x de ${brl(total / installments)}`
        : `Pagar ${brl(total)}`
      : method === "pix"
        ? "Copiar código Pix"
        : "Copiar linha digitável";

  function copyCode() {
    const text = method === "pix" ? (pix?.code ?? "") : BOLETO_LINE;
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  }


  function applyCoupon(code: string) {
    const key = code.trim().toUpperCase();
    if (!coupons[key]) {
      setCouponError("Cupom inválido.");
      return;
    }
    setCouponError(null);
    setCoupon(key);
  }

  function pay() {
    setFailure(null);
    if (method === "card") {
      const next: CardErrors = {};
      if (card.cvv.length < 3) next['cvv'] = "CVV incompleto";
      if (!useSavedCard) {
        if (!luhn(card.number)) next['number'] = "Confira o número";
        const expErr = validateExpiry(card.exp);
        if (expErr) next['exp'] = expErr;
        if (card.name.trim().length < 3) next['name'] = "Informe o nome";
        if (card.doc.replace(/\D/g, "").length < 11) next['doc'] = "Documento inválido";
      }
      setErrors(next);
      if (Object.keys(next).length) {
        document.getElementById(`cc-${Object.keys(next)[0]}`)?.focus();
        return;
      }
      setPending(true);
      setTimeout(() => {
        setPending(false);
        setFailure("Cartão não autorizado. Nada foi cobrado.");
      }, 900);
      return;
    }
    setPending(true);
    setTimeout(() => setPending(false), 900);
  }

  const actions = (
    <div className="grid gap-2">
      {failure && (
        <div role="alert" className="grid gap-2 rounded-2xl bg-destructive/10 p-3 text-sm">
          <p className="font-semibold text-destructive">{failure}</p>
          <Button
            variant="secondary"
            className="min-h-11"
            onClick={() => {
              setMethod("pix");
              setFailure(null);
            }}
          >
            Pagar com Pix
          </Button>
        </div>
      )}
      <Button
        size="lg"
        className="min-h-13 w-full text-base font-bold"
        onClick={method === "card" ? pay : copyCode}
        disabled={pending}
      >
        {pending ? "Processando…" : copied && method !== "card" ? "Código copiado" : ctaLabel}
      </Button>
      {method === "boleto" && (
        <Button variant="secondary" className="min-h-11 w-full" onClick={pay} disabled={pending}>
          Já paguei o boleto
        </Button>
      )}
      <p className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
        <Lock className="size-3.5" aria-hidden /> Rede | Itaú
      </p>
    </div>
  );


  return (
    <div className="min-h-screen bg-surface pb-36 lg:pb-12">
      <CheckoutHeader />

      <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
        <h1 className="sr-only">Pagamento da campanha</h1>
        <div className="grid gap-6 lg:grid-cols-[22rem_minmax(0,1fr)] lg:items-start lg:gap-10">

          <aside className="grid gap-3 lg:sticky lg:top-6">
            <OrderSummary
              subtotal={subtotal}
              discount={discount}
              total={total}
              coupon={coupon}
              couponError={couponError}
              onApplyCoupon={applyCoupon}
              onRemoveCoupon={() => setCoupon(null)}
              selectedAddOns={selectedAddOns}
              onToggleAddOn={(id) =>
                setSelectedAddOns((s) =>
                  s.includes(id) ? s.filter((x) => x !== id) : [...s, id],
                )
              }
            />
            <BillingSection
              profiles={profiles}
              active={activeProfile}
              onChangeActive={setActiveProfile}
              onRegister={(kind, data) =>
                setProfiles((p) => ({ ...p, [kind]: { ...p[kind], ...data } }))
              }
            />
          </aside>

          <div className="grid gap-4">
            <PaymentSection
              total={total}
              weeks={order.weeks}
              method={method}
              onMethod={(m) => {
                setMethod(m);
                setFailure(null);
              }}
              installments={installments}
              onInstallments={setInstallments}
              card={card}
              onCard={setCard}
              errors={errors}
              pix={pix}
              boletoIssued={boletoIssued}
              useSavedCard={useSavedCard}
              onUseSavedCard={setUseSavedCard}
              saveCard={saveCard}
              onSaveCard={setSaveCard}
            />
            <div className="hidden lg:grid lg:gap-3">{actions}</div>
            <HelpAccordion />
          </div>
        </div>
      </main>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background p-3 lg:hidden">
        <div className="mx-auto max-w-5xl">{actions}</div>
      </div>
    </div>

  );
}
